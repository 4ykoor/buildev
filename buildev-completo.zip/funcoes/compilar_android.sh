# Script para compilar projeto Android
