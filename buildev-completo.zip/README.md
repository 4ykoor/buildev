# Buildev

Sistema de build para Android e Web via Termux.