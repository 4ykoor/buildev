// Código base Android
